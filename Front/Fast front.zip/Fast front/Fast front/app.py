
import pandas as pd
import dash
from dash import html, dcc
import plotly.express as px

# Carrega os dados da planilha
df = pd.read_excel("fast.xlsx", sheet_name="fast")
df['Data'] = pd.to_datetime(df['Data'])

# Agrupamento por mês
df['Mês'] = df['Data'].dt.to_period('M').astype(str)
os_por_mes = df.groupby('Mês').size().reset_index(name='Quantidade')

# OS por estado
os_por_estado = df.groupby('Estado').size().reset_index(name='Quantidade')

# Principais causas
causas = df['Causa'].value_counts().reset_index()
causas.columns = ['Causa', 'Quantidade']

# Itens mais atendidos
itens = df['Item'].value_counts().reset_index()
itens.columns = ['Item', 'Quantidade']

# Tempo médio entre fabricação e emissão NF
df['Dt.Fabricação'] = pd.to_datetime(df['Dt.Fabricação'])
df['Dt.Emissão NF'] = pd.to_datetime(df['Dt.Emissão NF'])
df['Dias entre Fabricação e NF'] = (df['Dt.Emissão NF'] - df['Dt.Fabricação']).dt.days
tempo_medio = df['Dias entre Fabricação e NF'].mean()

# Iniciar o app Dash
app = dash.Dash(__name__)
app.title = "Dashboard OS - FAST"

app.layout = html.Div([
    html.H1("📊 Dashboard de Ordens de Serviço - FAST", style={'textAlign': 'center'}),

    html.H2("Quantidade de OS por Mês"),
    dcc.Graph(figure=px.bar(os_por_mes, x="Mês", y="Quantidade", title="OS por Mês")),

    html.H2("Distribuição de OS por Estado"),
    dcc.Graph(figure=px.pie(os_por_estado, names="Estado", values="Quantidade", title="OS por Estado")),

    html.H2("Principais Causas"),
    dcc.Graph(figure=px.bar(causas, x="Causa", y="Quantidade", title="Causas Mais Comuns", color="Quantidade")),

    html.H2("Modelos Mais Atendidos"),
    dcc.Graph(figure=px.bar(itens, x="Item", y="Quantidade", title="Itens com Mais OS", color="Quantidade")),

    html.H2("Tempo Médio entre Fabricação e Emissão de NF"),
    html.P(f"{tempo_medio:.2f} dias", style={'fontSize': '20px', 'fontWeight': 'bold'}),
])

if __name__ == "__main__":
    app.run(debug=True, port=8050)


