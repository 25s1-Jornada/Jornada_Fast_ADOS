import pandas as pd
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.express as px
# Carregar os dados
df = pd.read_excel("fast.xlsx", sheet_name="fast")
df = df.drop(columns=["Unnamed: 12"])  # Remove coluna irrelevante
df['Data'] = pd.to_datetime(df['Data'])

# Iniciar o app Dash
app = dash.Dash(__name__)
app.title = "Dashboard de Chamados"

app.layout = html.Div([
    html.H1("Análise de Chamados - FAST", style={'textAlign': 'center'}),

    # Filtros
    html.Div([
        dcc.DatePickerRange(
            id='date-range',
            start_date=df['Data'].min(),
            end_date=df['Data'].max(),
            display_format='DD/MM/YYYY'
        ),
        dcc.Dropdown(
            id='estado-dropdown',
            options=[{'label': est, 'value': est} for est in sorted(df['Estado'].unique())],
            multi=True,
            placeholder="Selecione Estado(s)"
        ),
        dcc.Dropdown(
            id='causa-dropdown',
            options=[{'label': causa, 'value': causa} for causa in sorted(df['Causa'].unique())],
            multi=True,
            placeholder="Selecione Causa(s)"
        ),
    ], style={'display': 'flex', 'gap': '20px', 'marginBottom': '30px'}),

    # Gráficos
    dcc.Graph(id='grafico-causa'),
    dcc.Graph(id='grafico-estado'),
    dcc.Graph(id='grafico-temporal')
])

@app.callback(
    [Output('grafico-causa', 'figure'),
     Output('grafico-estado', 'figure'),
     Output('grafico-temporal', 'figure')],
    [Input('date-range', 'start_date'),
     Input('date-range', 'end_date'),
     Input('estado-dropdown', 'value'),
     Input('causa-dropdown', 'value')]
)
def update_graficos(start_date, end_date, estados, causas):
    dff = df.copy()
    dff = dff[(dff['Data'] >= start_date) & (dff['Data'] <= end_date)]

    if estados:
        dff = dff[dff['Estado'].isin(estados)]
    if causas:
        dff = dff[dff['Causa'].isin(causas)]

    fig_causa = px.histogram(dff, x='Causa', title="Chamados por Causa", color='Causa')
    fig_estado = px.histogram(dff, x='Estado', title="Chamados por Estado", color='Estado')
    fig_data = px.histogram(dff, x='Data', title="Chamados ao Longo do Tempo")

    return fig_causa, fig_estado, fig_data

# Rodar localmente
if __name__ == '__main__':
    app.run_server(debug=True)
